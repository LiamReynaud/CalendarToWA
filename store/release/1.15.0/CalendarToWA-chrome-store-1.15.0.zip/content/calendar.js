(function () {
  if (!window.CalendarToWA) return;

  const {
    extractPhones,
    normalizeForWhatsApp,
    formatDisplay,
    parsePhoneParts,
    extractAttendeeNames,
    extractSuffixFromEvent,
    extractPipedriveContacts,
    extractTalentedCloserUrl,
    extractMeetUrl,
    normalizeMeetUrl,
    formatSuffixForWhatsApp,
    isRelativeDateLabel,
    resolveRelativeDateLabel,
    formatDateFromIso,
    formatTimeFromIso,
  } = window.CalendarToWA;

  const WIDGET_CLASS = "ctwa-widget";
  const BANNER_CLASS = "ctwa-banner";
  const WA_BANNER_CLASS = "ctwa-banner--wa";
  const ONOFF_BANNER_CLASS = "ctwa-banner--onoff";
  const MER_BANNER_CLASS = "ctwa-mer-banner";
  const GHL_BANNER_CLASS = "ctwa-ghl-banner";
  const HIDDEN_CLASS = "ctwa-banner--hidden";
  let defaultCountryCode = "33";
  let enableWhatsApp = true;
  let enableTalentedCloser = false;
  let enableMeridian = false;
  let enableGhl = false;
  let enableOnoff = false;
  let openWidget = null;
  let scanPaused = false;
  let cachedSuffixes = { suffixes: [], lastSuffix: "" };

  chrome.storage.sync.get(
    {
      defaultCountryCode: "33",
      suffixes: [],
      lastSuffix: "",
      enableWhatsApp: true,
      enableTalentedCloser: false,
      enableMeridian: false,
      enableGhl: false,
      enableOnoff: false,
    },
    (data) => {
      defaultCountryCode = data.defaultCountryCode || "33";
      enableWhatsApp = data.enableWhatsApp !== false;
      enableTalentedCloser =
        data.enableTalentedCloser === true || data.enablePipedrive === true;
      enableMeridian = data.enableMeridian === true;
      enableGhl = data.enableGhl === true;
      enableOnoff = data.enableOnoff === true;
      cachedSuffixes = {
        suffixes: data.suffixes || [],
        lastSuffix: data.lastSuffix || "",
      };
    }
  );

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "sync") return;
    if (changes.defaultCountryCode) {
      defaultCountryCode = changes.defaultCountryCode.newValue || "33";
      rescanAll();
    }
    if (changes.enableWhatsApp) {
      enableWhatsApp = changes.enableWhatsApp.newValue !== false;
      rescanAll();
    }
    if (changes.enableTalentedCloser) {
      enableTalentedCloser = changes.enableTalentedCloser.newValue === true;
      rescanAll();
    }
    if (changes.enableMeridian) {
      enableMeridian = changes.enableMeridian.newValue === true;
      rescanAll();
    }
    if (changes.enableGhl) {
      enableGhl = changes.enableGhl.newValue === true;
      rescanAll();
    }
    if (changes.enableOnoff) {
      enableOnoff = changes.enableOnoff.newValue === true;
      rescanAll();
    }
    if (changes.suffixes || changes.lastSuffix) {
      chrome.storage.sync.get({ suffixes: [], lastSuffix: "" }, (data) => {
        cachedSuffixes = {
          suffixes: data.suffixes || [],
          lastSuffix: data.lastSuffix || "",
        };
      });
    }
  });

  const IGNORED_PANEL_TITLES =
    /^(Agenda|Panneau|Paramètres|Settings|Semaine du |Page de modification)/i;

  function isVisiblePanel(el) {
    if (!el?.isConnected) return false;
    const style = window.getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden") return false;
    const r = el.getBoundingClientRect();
    return r.width >= 200 && r.height >= 150;
  }

  function scoreEventPanel(el) {
    if (!isVisiblePanel(el)) return -1;

    let score = 0;
    const heading = el.querySelector('[role="heading"]');
    const title = heading?.textContent?.trim() || "";
    if (heading && title && !IGNORED_PANEL_TITLES.test(title)) score += 20;

    const text = el.textContent || "";
    if (/créé par|created by/i.test(text)) score += 15;
    if (/Deal:\s/i.test(text)) score += 40;
    if (/Contact:.*Phone:/i.test(text)) score += 40;
    if (/minutes?\s+(avant|before)/i.test(text)) score += 10;
    if (
      el.querySelector(
        '[aria-label="Description"], [aria-label*="Description"], [aria-label*="description"]'
      )
    ) {
      score += 5;
    }

    if (
      el.closest('[role="complementary"]') &&
      el.querySelector('[role="list"], [role="tree"]') &&
      !heading
    ) {
      score -= 40;
    }

    return score;
  }

  function collectEventPanelCandidates() {
    const candidates = new Set();

    document.querySelectorAll('[role="dialog"]').forEach((el) => candidates.add(el));

    document.querySelectorAll('[role="heading"]').forEach((heading) => {
      const title = heading.textContent?.trim() || "";
      if (!title || IGNORED_PANEL_TITLES.test(title)) return;

      let node = heading.parentElement;
      for (let depth = 0; depth < 25 && node && node !== document.body; depth++) {
        const r = node.getBoundingClientRect();
        const text = node.textContent || "";
        if (
          r.height >= 180 &&
          r.width >= 260 &&
          /créé par|created by|minutes?\s+(avant|before)/i.test(text)
        ) {
          candidates.add(node);
          break;
        }
        node = node.parentElement;
      }
    });

    if (location.pathname.includes("/eventedit/")) {
      const main = document.querySelector('[role="main"]');
      if (main) candidates.add(main);
    }

    return [...candidates];
  }

  function getOpenPanel() {
    let best = null;
    let bestScore = 0;

    for (const el of collectEventPanelCandidates()) {
      const score = scoreEventPanel(el);
      if (score > bestScore) {
        bestScore = score;
        best = el;
      }
    }

    return bestScore >= 10 ? best : null;
  }

  function extractEventTitle(panel) {
    const h = panel.querySelector('[role="heading"]');
    if (h?.textContent?.trim()) return h.textContent.trim();
    const input = panel.querySelector('[aria-label="Titre"]');
    return (input?.value || input?.textContent || "").trim();
  }

  function readPanelFieldValue(el) {
    if (!el) return "";
    const raw =
      el.value ??
      el.getAttribute?.("value") ??
      el.getAttribute?.("datetime") ??
      el.textContent ??
      "";
    return String(raw).trim();
  }

  function pickPanelField(root, labels) {
    if (!root) return "";
    for (const label of labels) {
      const exact = root.querySelector(`[aria-label="${label}"]`);
      const value = readPanelFieldValue(exact);
      if (value) return value;
      const partial = root.querySelector(`[aria-label*="${label}"]`);
      const partialValue = readPanelFieldValue(partial);
      if (partialValue) return partialValue;
    }
    return "";
  }

  function normalizeStartTime(timeStr) {
    if (!timeStr) return "";
    const trimmed = String(timeStr).trim();
    const ampm = trimmed.match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
    if (ampm) {
      let hour = parseInt(ampm[1], 10);
      const minute = ampm[2];
      if (ampm[3].toUpperCase() === "PM" && hour < 12) hour += 12;
      if (ampm[3].toUpperCase() === "AM" && hour === 12) hour = 0;
      return `${String(hour).padStart(2, "0")}:${minute}`;
    }
    return (
      trimmed.match(/De\s+(\d{1,2}:\d{2})/i)?.[1] ||
      trimmed.match(/^(\d{1,2}:\d{2})/)?.[1] ||
      trimmed
    );
  }

  function extractDateTimeHintsFromText(text) {
    let date = "";
    let startTime = "";
    if (!text || typeof text !== "string") return { date, startTime };

    const monthsFr =
      "janvier|février|fevrier|mars|avril|mai|juin|juillet|août|aout|septembre|octobre|novembre|décembre|decembre";
    const monthsEn =
      "january|february|march|april|may|june|july|august|september|october|november|december";
    const monthsShort = "jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec";

    const datePatterns = [
      new RegExp(
        `(?:lundi|mardi|mercredi|jeudi|vendredi|samedi|dimanche)[\\s,]*\\d{1,2}\\s+(?:${monthsFr})(?:\\s+\\d{4})?`,
        "i"
      ),
      new RegExp(
        `(?:Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)[\\s,]*\\d{1,2}\\s+(?:${monthsEn})(?:\\s+\\d{4})?`,
        "i"
      ),
      new RegExp(`\\d{1,2}\\s+(?:${monthsShort})[a-z]*\\.?\\s+\\d{4}`, "i"),
      /\d{1,2}\/\d{1,2}\/\d{4}/,
      new RegExp(`on\\s+(\\d{1,2}\\s+(?:${monthsShort})[a-z]*\\.?\\s+\\d{4})`, "i"),
      /scheduled for\s+(\d{1,2}\s+[A-Za-z]{3,9}\.?\s+\d{4})/i,
    ];

    for (const pattern of datePatterns) {
      const match = text.match(pattern);
      if (match) {
        date = (match[1] || match[0]).trim();
        break;
      }
    }

    const timePatterns = [
      /(?:⋅|,|\s)De\s+(\d{1,2}:\d{2})\s+à\s+\d{1,2}:\d{2}/i,
      /From\s+(\d{1,2}:\d{2})\s*(AM|PM)?\s+to/i,
      /scheduled for\s+\d{1,2}\s+\w+\s+\d{4}\s+at\s+(\d{1,2}:\d{2})/i,
      /\bat\s+(\d{1,2}:\d{2})\s*(?:-\s*Europe|$|\()/i,
      /(\d{1,2}:\d{2})\s*(AM|PM)\s*[–—-]/i,
      /(\d{1,2}:\d{2})\s*[–—-]\s*\d{1,2}:\d{2}/,
    ];

    for (const pattern of timePatterns) {
      const match = text.match(pattern);
      if (match) {
        startTime = match[2] && /^[AP]M$/i.test(match[2])
          ? `${match[1]} ${match[2]}`
          : match[1];
        break;
      }
    }

    if (date && !/\d{4}/.test(date)) {
      const yearMatch =
        text.match(/\bon\s+\d{1,2}\s+\w+\s+(\d{4})\b/i) ||
        text.match(/scheduled for\s+\d{1,2}\s+\w+\s+(\d{4})/i);
      if (yearMatch) date = `${date} ${yearMatch[1]}`;
    }

    return { date, startTime };
  }

  function formatEventDateTime(date, startTime) {
    let d = String(date || "").trim();
    if (/^\d{4}-\d{2}-\d{2}/.test(d)) {
      d = formatDateFromIso(d);
    } else if (isRelativeDateLabel(d)) {
      d = resolveRelativeDateLabel(d);
    }
    const t = normalizeStartTime(startTime);
    if (d && t) return `${d} — ${t}`;
    return d || t || "";
  }

  function extractIsoDateTimeFromScopes(scopes) {
    for (const scope of scopes) {
      for (const el of scope.querySelectorAll("time[datetime], [datetime]") || []) {
        const iso = el.getAttribute("datetime");
        if (!iso || !/^\d{4}-\d{2}-\d{2}/.test(iso)) continue;
        const date = formatDateFromIso(iso);
        if (date) {
          return { date, startTime: formatTimeFromIso(iso) };
        }
      }

      const dataDateEl = scope.querySelector("[data-date]");
      const dataDate = dataDateEl?.getAttribute("data-date");
      if (dataDate && /^\d{4}-\d{2}-\d{2}/.test(dataDate)) {
        const date = formatDateFromIso(dataDate);
        if (date) return { date, startTime: "" };
      }
    }
    return { date: "", startTime: "" };
  }

  function extractEventDateTime(panel) {
    const scopes = [panel, document].filter(Boolean);
    const dateLabels = [
      "Date de début",
      "Date",
      "Start date",
      "Date de l'événement",
    ];
    const startLabels = [
      "Heure de début",
      "Start time",
      "Heure",
    ];
    let date = "";
    let startTime = "";

    const isoHints = extractIsoDateTimeFromScopes(scopes);
    if (isoHints.date) date = isoHints.date;
    if (isoHints.startTime) startTime = isoHints.startTime;

    for (const scope of scopes) {
      const fieldDate = pickPanelField(scope, dateLabels);
      const fieldStartTime = pickPanelField(scope, startLabels);
      if (fieldDate && !date) date = fieldDate;
      else if (fieldDate && isRelativeDateLabel(date) && !isoHints.date) {
        date = fieldDate;
      }
      if (!startTime && fieldStartTime) startTime = fieldStartTime;
      if (date && startTime && !isRelativeDateLabel(date)) break;
    }

    if (!startTime) {
      for (const scope of scopes) {
        const endOnly = pickPanelField(scope, ["Heure de fin", "End time"]);
        if (endOnly) {
          startTime = endOnly;
          break;
        }
      }
    }

    if (!date || !startTime) {
      for (const scope of scopes) {
        for (const el of scope.querySelectorAll(
          "div, span, button, time, input, [datetime]"
        )) {
          const text = readPanelFieldValue(el);
          if (!text || text.length > 160) continue;
          const hints = extractDateTimeHintsFromText(text);
          if (!date && hints.date) date = hints.date;
          else if (hints.date && isRelativeDateLabel(date)) date = hints.date;
          if (!startTime && hints.startTime) startTime = hints.startTime;
          if (date && startTime) break;
        }
        if (date && startTime) break;
      }
    }

    if (!date) {
      for (const scope of scopes) {
        const dated = scope.querySelector("[data-date], time[datetime]");
        const raw =
          dated?.getAttribute("data-date") || dated?.getAttribute("datetime");
        if (raw && /^\d{4}-\d{2}-\d{2}/.test(raw)) {
          date = formatDateFromIso(raw);
          if (!startTime) startTime = formatTimeFromIso(raw);
          break;
        }
      }
    }

    if (!date || !startTime) {
      const { title, text } = extractPanelText(panel);
      const hints = extractDateTimeHintsFromText([title, text].filter(Boolean).join("\n"));
      if (!date) date = hints.date;
      if (!startTime) startTime = hints.startTime;
    }

    return formatEventDateTime(date, startTime);
  }

  function extractEventDescription(panel) {
    const labels = [
      "Description",
      "Description de l'événement",
      "Event description",
      "Notes",
    ];

    for (const label of labels) {
      const value = pickPanelField(panel, [label]);
      if (value) return value;
    }

    let best = "";
    for (const el of panel.querySelectorAll("div, p, span, pre")) {
      const t = (el.textContent || "").trim();
      if (t.length < 8 || t.length > 2000) continue;
      if (/Deal:\s|Contact:.*Phone:|Num[ée]ro\s*:|Phone\s*Number\s*:|T[ée]l[ée]phone\s*:/i.test(t)) {
        if (!best || t.length < best.length) best = t;
      }
    }
    return best;
  }

  function extractPanelText(panel) {
    const title = extractEventTitle(panel);
    const desc = extractEventDescription(panel);
    const body = (panel.textContent || "").slice(0, 8000);
    return { title, text: [title, desc, body].filter(Boolean).join("\n") };
  }

  function phoneResultFromRaw(raw) {
    const normalized = normalizeForWhatsApp(raw, defaultCountryCode);
    if (!normalized) return null;
    const parts = parsePhoneParts(normalized, defaultCountryCode);
    return {
      raw,
      normalized,
      display: formatDisplay(raw),
      countryCode: parts.countryCode,
      nationalNumber: parts.nationalNumber,
    };
  }

  function findPhonesInPanel(panel) {
    const { text } = extractPanelText(panel);
    const rawPhones = extractPhones(text, {
      excludeMeetingDialIn: true,
      defaultCountryCode,
    });
    const results = [];

    for (const raw of rawPhones) {
      const entry = phoneResultFromRaw(raw);
      if (entry) results.push(entry);
    }

    for (const { phoneRaw } of extractPipedriveContacts(text)) {
      if (!phoneRaw) continue;
      const entry = phoneResultFromRaw(phoneRaw);
      if (entry) results.push(entry);
    }

    const seen = new Set();
    return results.filter((p) => {
      if (seen.has(p.normalized)) return false;
      seen.add(p.normalized);
      return true;
    });
  }

  function extractTalentedCloserUrlFromPanel(panel) {
    if (!panel) return "";

    for (const link of panel.querySelectorAll(
      'a[href*="talentedclosers.com/crm/leads/"]'
    )) {
      const url = extractTalentedCloserUrl(link.getAttribute("href") || "");
      if (url) return url;
    }

    const { text } = extractPanelText(panel);
    return extractTalentedCloserUrl(text);
  }

  function getAttendeeNames(panel) {
    const { title, text } = extractPanelText(panel);
    return extractAttendeeNames(title, text);
  }

  function getEventSuffix(panel) {
    const { title, text } = extractPanelText(panel);
    return extractSuffixFromEvent(title, text, cachedSuffixes.suffixes);
  }

  function removeBanner(panel) {
    panel.querySelectorAll(`.${WIDGET_CLASS}`).forEach((el) => el.remove());
    if (openWidget && !document.contains(openWidget)) openWidget = null;
  }

  function closeAllOverlays(exceptWidget, exceptType) {
    document.querySelectorAll(`.${WIDGET_CLASS}`).forEach((widget) => {
      const keepWa = widget === exceptWidget && exceptType === "wa";
      const keepOnoff = widget === exceptWidget && exceptType === "onoff";
      const keepMer = widget === exceptWidget && exceptType === "mer";
      const keepGhl = widget === exceptWidget && exceptType === "ghl";

      if (!keepWa) {
        widget.querySelector(`.${WA_BANNER_CLASS}`)?.classList.add(HIDDEN_CLASS);
        widget
          .querySelector(".ctwa-trigger--wa")
          ?.setAttribute("aria-expanded", "false");
      }

      if (!keepOnoff) {
        widget.querySelector(`.${ONOFF_BANNER_CLASS}`)?.classList.add(HIDDEN_CLASS);
        widget
          .querySelector(".ctwa-trigger--onoff")
          ?.setAttribute("aria-expanded", "false");
      }

      if (!keepMer) {
        widget.querySelector(`.${MER_BANNER_CLASS}`)?.classList.add(HIDDEN_CLASS);
        widget
          .querySelector(".ctwa-trigger--meridian")
          ?.setAttribute("aria-expanded", "false");
      }

      if (!keepGhl) {
        widget.querySelector(`.${GHL_BANNER_CLASS}`)?.classList.add(HIDDEN_CLASS);
        widget
          .querySelector(".ctwa-trigger--ghl")
          ?.setAttribute("aria-expanded", "false");
      }
    });

    if (openWidget && openWidget !== exceptWidget) openWidget = null;
  }

  function toggleOverlay(widget, type) {
    const config = {
      wa: { banner: `.${WA_BANNER_CLASS}`, trigger: ".ctwa-trigger--wa" },
      onoff: { banner: `.${ONOFF_BANNER_CLASS}`, trigger: ".ctwa-trigger--onoff" },
      mer: { banner: `.${MER_BANNER_CLASS}`, trigger: ".ctwa-trigger--meridian" },
      ghl: { banner: `.${GHL_BANNER_CLASS}`, trigger: ".ctwa-trigger--ghl" },
    }[type];
    if (!config) return;

    const banner = widget.querySelector(config.banner);
    const trigger = widget.querySelector(config.trigger);
    if (!banner || !trigger) return;

    const willOpen = banner.classList.contains(HIDDEN_CLASS);
    closeAllOverlays(willOpen ? widget : null, willOpen ? type : null);

    if (willOpen) {
      banner.classList.remove(HIDDEN_CLASS);
      trigger.setAttribute("aria-expanded", "true");
      openWidget = widget;
    } else {
      banner.classList.add(HIDDEN_CLASS);
      trigger.setAttribute("aria-expanded", "false");
      openWidget = null;
    }
  }

  const WA_ICON_SVG = `
    <svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
      <path d="M12 0C5.373 0 0 5.373 0 12c0 2.625.846 5.059 2.284 7.034L.789 23.492a.5.5 0 0 0 .609.609l4.458-1.495A11.945 11.945 0 0 0 12 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 22c-2.387 0-4.592-.832-6.323-2.22l-.448-.372-2.605.872.872-2.538-.39-.453A9.969 9.969 0 0 1 2 12C2 6.477 6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/>
    </svg>`;

  function getMeridianPhoneQuery(phone) {
    return phone.normalized || phone.raw.replace(/\D/g, "") || phone.display;
  }

  function getMeridianPhoneRows(panel) {
    return findPhonesInPanel(panel || getOpenPanel()).map((phone) => ({ phone }));
  }

  function createMeridianBannerRow(rowData) {
    const { phone } = rowData;
    const row = document.createElement("div");
    row.className = "ctwa-mer-banner__row";

    const phoneField = document.createElement("div");
    phoneField.className = "ctwa-mer-banner__field";
    const phoneLabel = document.createElement("span");
    phoneLabel.className = "ctwa-mer-banner__label";
    phoneLabel.textContent = "Téléphone";
    const phoneValue = document.createElement("span");
    phoneValue.className = "ctwa-mer-banner__value";
    phoneValue.textContent = phone?.display || phone?.raw || "—";
    phoneField.append(phoneLabel, phoneValue);
    row.appendChild(phoneField);

    const searchBtn = document.createElement("button");
    searchBtn.type = "button";
    searchBtn.className = "ctwa-mer-banner__btn";
    searchBtn.textContent = "Rechercher dans Meridian";
    searchBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      openMeridianSearch(getMeridianPhoneQuery(phone), searchBtn);
    });
    row.appendChild(searchBtn);

    return row;
  }

  function fillMeridianBanner(banner, panel) {
    const list = banner.querySelector(".ctwa-mer-banner__list");
    if (!list) return;
    list.replaceChildren();

    const rows = getMeridianPhoneRows(panel);
    if (rows.length === 0) {
      const empty = document.createElement("p");
      empty.className = "ctwa-mer-banner__hint";
      empty.textContent = "Aucun numéro détecté dans cet événement.";
      list.appendChild(empty);
      return;
    }

    rows.forEach((rowData) => {
      list.appendChild(createMeridianBannerRow(rowData));
    });
  }

  function createMeridianBanner(panel) {
    const banner = document.createElement("div");
    banner.className = `${MER_BANNER_CLASS} ${HIDDEN_CLASS}`;
    banner.setAttribute("role", "region");
    banner.setAttribute("aria-label", "Recherche Meridian");

    const header = document.createElement("div");
    header.className = "ctwa-mer-banner__header";
    header.innerHTML = `
      <span class="ctwa-mer-banner__title">Rechercher dans Meridian</span>
      <button type="button" class="ctwa-mer-banner__close" aria-label="Fermer">×</button>
    `;
    banner.appendChild(header);

    header.querySelector(".ctwa-mer-banner__close").addEventListener("click", (e) => {
      e.stopPropagation();
      banner.classList.add(HIDDEN_CLASS);
      banner
        .closest(`.${WIDGET_CLASS}`)
        ?.querySelector(".ctwa-trigger--meridian")
        ?.setAttribute("aria-expanded", "false");
      openWidget = null;
    });

    const list = document.createElement("div");
    list.className = "ctwa-mer-banner__list";
    banner.appendChild(list);

    fillMeridianBanner(banner, panel);
    return banner;
  }

  function getGhlPhoneQuery(phone) {
    return phone.normalized || phone.raw.replace(/\D/g, "") || phone.display;
  }

  function getGhlPhoneRows(panel) {
    return findPhonesInPanel(panel || getOpenPanel()).map((phone) => ({ phone }));
  }

  function createGhlBannerRow(rowData) {
    const { phone } = rowData;
    const row = document.createElement("div");
    row.className = "ctwa-ghl-banner__row";

    const phoneField = document.createElement("div");
    phoneField.className = "ctwa-ghl-banner__field";
    const phoneLabel = document.createElement("span");
    phoneLabel.className = "ctwa-ghl-banner__label";
    phoneLabel.textContent = "Téléphone";
    const phoneValue = document.createElement("span");
    phoneValue.className = "ctwa-ghl-banner__value";
    phoneValue.textContent = phone?.display || phone?.raw || "—";
    phoneField.append(phoneLabel, phoneValue);
    row.appendChild(phoneField);

    const searchBtn = document.createElement("button");
    searchBtn.type = "button";
    searchBtn.className = "ctwa-ghl-banner__btn";
    searchBtn.textContent = "Rechercher dans GHL";
    searchBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      openGhlSearch(getGhlPhoneQuery(phone), searchBtn);
    });
    row.appendChild(searchBtn);

    return row;
  }

  function fillGhlBanner(banner, panel) {
    const list = banner.querySelector(".ctwa-ghl-banner__list");
    if (!list) return;
    list.replaceChildren();

    const rows = getGhlPhoneRows(panel);
    if (rows.length === 0) {
      const empty = document.createElement("p");
      empty.className = "ctwa-ghl-banner__hint";
      empty.textContent = "Aucun numéro détecté dans cet événement.";
      list.appendChild(empty);
      return;
    }

    rows.forEach((rowData) => {
      list.appendChild(createGhlBannerRow(rowData));
    });
  }

  function createGhlBanner(panel) {
    const banner = document.createElement("div");
    banner.className = `${GHL_BANNER_CLASS} ${HIDDEN_CLASS}`;
    banner.setAttribute("role", "region");
    banner.setAttribute("aria-label", "Recherche GoHighLevel");

    const header = document.createElement("div");
    header.className = "ctwa-ghl-banner__header";
    header.innerHTML = `
      <span class="ctwa-ghl-banner__title">Rechercher dans GHL</span>
      <button type="button" class="ctwa-ghl-banner__close" aria-label="Fermer">×</button>
    `;
    banner.appendChild(header);

    header.querySelector(".ctwa-ghl-banner__close").addEventListener("click", (e) => {
      e.stopPropagation();
      banner.classList.add(HIDDEN_CLASS);
      banner
        .closest(`.${WIDGET_CLASS}`)
        ?.querySelector(".ctwa-trigger--ghl")
        ?.setAttribute("aria-expanded", "false");
      openWidget = null;
    });

    const list = document.createElement("div");
    list.className = "ctwa-ghl-banner__list";
    banner.appendChild(list);

    fillGhlBanner(banner, panel);
    return banner;
  }

  function saveSuffix(suffix) {
    const trimmed = (suffix || "").trim();
    if (!trimmed) return;

    chrome.storage.sync.get({ suffixes: [], lastSuffix: "" }, (data) => {
      const suffixes = [...(data.suffixes || [])];
      if (!suffixes.includes(trimmed)) suffixes.unshift(trimmed);
      chrome.storage.sync.set(
      {
        suffixes: suffixes.slice(0, 20),
        lastSuffix: trimmed,
      },
      () => {
        cachedSuffixes = { suffixes: suffixes.slice(0, 20), lastSuffix: trimmed };
      }
    );
    });
  }

  function buildSelect(options, selectedValue, customOptionLabel) {
    const select = document.createElement("select");
    select.className = "ctwa-banner__select";

    for (const opt of options) {
      const option = document.createElement("option");
      option.value = opt.value;
      option.textContent = opt.label;
      if (opt.value === selectedValue) option.selected = true;
      select.appendChild(option);
    }

    const custom = document.createElement("option");
    custom.value = "__custom__";
    custom.textContent = customOptionLabel;
    if (selectedValue === "__custom__") custom.selected = true;
    select.appendChild(custom);

    return select;
  }

  function extractMeetUrlFromPanel(panel) {
    if (!panel) return "";

    for (const link of panel.querySelectorAll('a[href*="meet.google.com"]')) {
      const url = extractMeetUrl(link.getAttribute("href") || link.textContent || "");
      if (url) return url;
    }

    const location = pickPanelField(panel, ["Lieu", "Location"]);
    const fromLocation = extractMeetUrl(location);
    if (fromLocation) return fromLocation;

    const { text } = extractPanelText(panel);
    return extractMeetUrl(text);
  }

  function appendMeetLinkField(form, meetUrl) {
    if (!meetUrl) return;

    const meetLabel = document.createElement("span");
    meetLabel.className = "ctwa-banner__label";
    meetLabel.textContent = "Visio Meet";
    form.appendChild(meetLabel);

    const meetLink = document.createElement("a");
    meetLink.className = "ctwa-banner__meet-link";
    meetLink.href = meetUrl;
    meetLink.target = "_blank";
    meetLink.rel = "noopener noreferrer";
    meetLink.textContent = meetUrl.replace(/^https:\/\//, "");
    form.appendChild(meetLink);
  }

  function createPhoneRow(
    phone,
    names,
    suffixes,
    lastSuffix,
    detectedSuffix = "",
    meetUrl = "",
    destination = "wa"
  ) {
    const isOnoff = destination === "onoff";
    const row = document.createElement("div");
    row.className = "ctwa-banner__row";

    const phoneEl = document.createElement("span");
    phoneEl.className = "ctwa-banner__phone";
    phoneEl.textContent = phone.display;
    row.appendChild(phoneEl);

    const form = document.createElement("div");
    form.className = "ctwa-banner__form";

    const nameLabel = document.createElement("label");
    nameLabel.className = "ctwa-banner__label";
    nameLabel.textContent = isOnoff ? "Nom complet" : "Prénom (WhatsApp)";
    form.appendChild(nameLabel);

    const nameOptions = names.map((n) => ({ value: n, label: n }));
    if (nameOptions.length === 0) {
      nameOptions.push({ value: "", label: "— Saisir ci-dessous —" });
    }
    const nameSelect = buildSelect(nameOptions, nameOptions[0]?.value || "", "Autre…");
    form.appendChild(nameSelect);

    const nameCustom = document.createElement("input");
    nameCustom.type = "text";
    nameCustom.className = "ctwa-banner__input";
    nameCustom.placeholder = "Prénom personnalisé";
    nameCustom.hidden = nameSelect.value !== "__custom__";
    form.appendChild(nameCustom);

    nameSelect.addEventListener("change", () => {
      nameCustom.hidden = nameSelect.value !== "__custom__";
    });

    const suffixLabel = document.createElement("label");
    suffixLabel.className = "ctwa-banner__label";
    suffixLabel.textContent = isOnoff
      ? "Entreprise (équipe, ex. [YBS])"
      : "Suffixe → nom WhatsApp";
    form.appendChild(suffixLabel);

    const suffixList = [
      ...new Set([detectedSuffix, ...(suffixes || []), lastSuffix].filter(Boolean)),
    ];
    const suffixOptions = [
      { value: "", label: "— Aucun —" },
      ...suffixList.map((s) => ({ value: s, label: s })),
    ];
    const defaultSuffix =
      (detectedSuffix && suffixList.includes(detectedSuffix) && detectedSuffix) ||
      (lastSuffix && suffixList.includes(lastSuffix) ? lastSuffix : "");
    const suffixSelect = buildSelect(suffixOptions, defaultSuffix, "Autre…");
    form.appendChild(suffixSelect);

    const suffixCustom = document.createElement("input");
    suffixCustom.type = "text";
    suffixCustom.className = "ctwa-banner__input";
    suffixCustom.placeholder = "Suffixe personnalisé (ex. YBS)";
    suffixCustom.hidden = suffixSelect.value !== "__custom__";
    form.appendChild(suffixCustom);

    suffixSelect.addEventListener("change", () => {
      suffixCustom.hidden = suffixSelect.value !== "__custom__";
    });

    appendMeetLinkField(form, meetUrl);

    function readNameAndSuffix() {
      let selectedName =
        nameSelect.value === "__custom__"
          ? nameCustom.value.trim()
          : nameSelect.value.trim();

      let suffixRaw =
        suffixSelect.value === "__custom__"
          ? suffixCustom.value.trim()
          : suffixSelect.value.trim();

      if (!selectedName) {
        nameCustom.hidden = false;
        nameCustom.focus();
        nameCustom.placeholder = "Prénom requis";
        return null;
      }

      if (suffixRaw) saveSuffix(suffixRaw);

      const panel = getOpenPanel();
      const eventDate = extractEventDateTime(panel);
      const { firstName, lastName } = splitSelectedPersonName(selectedName);

      return {
        selectedName,
        suffixRaw,
        eventDate,
        firstName,
        lastName,
        companyName: formatSuffixForWhatsApp(suffixRaw),
      };
    }

    const waBtn = document.createElement("button");
    waBtn.type = "button";
    waBtn.className = "ctwa-banner__btn";
    waBtn.textContent = "Créer ou ouvrir le contact";
    waBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      const data = readNameAndSuffix();
      if (!data) return;

      openWhatsAppContact(
        {
          phone: phone.normalized,
          rawPhone: phone.raw,
          countryCode: phone.countryCode,
          nationalNumber: phone.nationalNumber,
          firstName: data.selectedName,
          lastName: formatSuffixForWhatsApp(data.suffixRaw),
          searchNames: names,
          eventDate: data.eventDate,
          meetUrl,
        },
        waBtn
      );
    });
    if (!isOnoff) form.appendChild(waBtn);

    const onoffBtn = document.createElement("button");
    onoffBtn.type = "button";
    onoffBtn.className = "ctwa-banner__btn ctwa-banner__btn--onoff";
    onoffBtn.textContent = "Créer ou ouvrir sur Onoff";
    onoffBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      const data = readNameAndSuffix();
      if (!data) return;

      openOnoffContact(
        {
          phone: phone.normalized,
          rawPhone: phone.raw,
          countryCode: phone.countryCode,
          nationalNumber: phone.nationalNumber,
          firstName: data.firstName,
          lastName: data.lastName,
          companyName: data.companyName,
          eventDate: data.eventDate,
          meetUrl,
        },
        onoffBtn
      );
    });
    if (isOnoff) form.appendChild(onoffBtn);

    row.appendChild(form);
    return row;
  }

  function splitSelectedPersonName(fullName) {
    const trimmed = (fullName || "").trim();
    if (!trimmed) return { firstName: "", lastName: "" };
    const parts = trimmed.split(/\s+/);
    if (parts.length === 1) return { firstName: parts[0], lastName: "" };
    return { firstName: parts[0], lastName: parts.slice(1).join(" ") };
  }

  function appendContactsBanner(widget, options) {
    const {
      kind,
      title,
      ariaLabel,
      trigger,
      phones,
      panel,
      suffixes,
      lastSuffix,
    } = options;

    const bannerClass = kind === "onoff" ? ONOFF_BANNER_CLASS : WA_BANNER_CLASS;
    const banner = document.createElement("div");
    banner.className = `${BANNER_CLASS} ${bannerClass} ${HIDDEN_CLASS}`;
    banner.setAttribute("role", "region");
    banner.setAttribute("aria-label", ariaLabel);

    const names = getAttendeeNames(panel);
    const detectedSuffix = getEventSuffix(panel);

    const header = document.createElement("div");
    header.className = "ctwa-banner__header";
    header.innerHTML = `
      <span class="ctwa-banner__title">${title}</span>
      <button type="button" class="ctwa-banner__close" aria-label="Fermer">×</button>
    `;
    banner.appendChild(header);

    header.querySelector(".ctwa-banner__close").addEventListener("click", (e) => {
      e.stopPropagation();
      banner.classList.add(HIDDEN_CLASS);
      trigger.setAttribute("aria-expanded", "false");
      openWidget = null;
    });

    if (names.length > 0) {
      const hint = document.createElement("p");
      hint.className = "ctwa-banner__hint";
      hint.textContent = `${names.length} nom(s) détecté(s) dans la réunion`;
      banner.appendChild(hint);
    }

    const meetUrl = extractMeetUrlFromPanel(panel);
    const list = document.createElement("div");
    list.className = "ctwa-banner__list";
    phones.forEach((phone) => {
      list.appendChild(
        createPhoneRow(
          phone,
          names,
          suffixes,
          lastSuffix,
          detectedSuffix,
          meetUrl,
          kind
        )
      );
    });
    banner.appendChild(list);
    widget.appendChild(banner);

    trigger.addEventListener("click", (e) => {
      e.stopPropagation();
      toggleOverlay(widget, kind);
    });
  }

  function createWidget(phones, panel, suffixes, lastSuffix, options = {}) {
    const {
      showWhatsApp = true,
      showOnoff = false,
      showTalentedCloser = false,
      tcUrl = "",
      showMeridian = false,
      showGhl = false,
    } = options;
    const widget = document.createElement("div");
    widget.className = WIDGET_CLASS;

    const triggers = document.createElement("div");
    triggers.className = "ctwa-triggers";

    let waTrigger = null;

    if (showWhatsApp && phones.length > 0) {
      waTrigger = document.createElement("button");
      waTrigger.type = "button";
      waTrigger.className = "ctwa-trigger ctwa-trigger--wa";
      waTrigger.setAttribute("aria-label", "Ajouter le contact sur WhatsApp");
      waTrigger.setAttribute("aria-expanded", "false");
      waTrigger.title = "Ajouter sur WhatsApp";
      waTrigger.innerHTML = WA_ICON_SVG;
      triggers.appendChild(waTrigger);
    }

    let onoffTrigger = null;
    if (showOnoff && phones.length > 0) {
      onoffTrigger = document.createElement("button");
      onoffTrigger.type = "button";
      onoffTrigger.className = "ctwa-trigger ctwa-trigger--onoff";
      onoffTrigger.setAttribute("aria-label", "Ajouter le contact sur Onoff");
      onoffTrigger.setAttribute("aria-expanded", "false");
      onoffTrigger.title = "Ajouter sur Onoff";

      const onoffIcon = document.createElement("img");
      onoffIcon.src = chrome.runtime.getURL("icons/onoff.png");
      onoffIcon.alt = "";
      onoffIcon.width = 20;
      onoffIcon.height = 20;
      onoffTrigger.appendChild(onoffIcon);

      triggers.appendChild(onoffTrigger);
    }

    if (showTalentedCloser && tcUrl) {
      triggers.appendChild(createTalentedCloserTrigger(tcUrl));
    }

    if (showMeridian) {
      triggers.appendChild(createMeridianTrigger(widget, panel));
    }

    if (showGhl) {
      triggers.appendChild(createGhlTrigger(widget, panel));
    }

    widget.appendChild(triggers);

    if (showWhatsApp && waTrigger) {
      appendContactsBanner(widget, {
        kind: "wa",
        title: "Ajouter sur WhatsApp",
        ariaLabel: "Contacts WhatsApp détectés",
        trigger: waTrigger,
        phones,
        panel,
        suffixes,
        lastSuffix,
      });
    }

    if (showOnoff && onoffTrigger) {
      appendContactsBanner(widget, {
        kind: "onoff",
        title: "Ajouter sur Onoff",
        ariaLabel: "Contacts Onoff détectés",
        trigger: onoffTrigger,
        phones,
        panel,
        suffixes,
        lastSuffix,
      });
    }

    if (showMeridian) {
      widget.appendChild(createMeridianBanner(panel));
    }

    if (showGhl) {
      widget.appendChild(createGhlBanner(panel));
    }

    return widget;
  }

  function openMeridianSearch(query, btn) {
    const trimmed = (query || "").trim();
    if (!trimmed) {
      if (btn) {
        btn.textContent = "Aucun numéro détecté";
        setTimeout(() => {
          btn.textContent = "Rechercher dans Meridian";
        }, 2000);
      }
      return;
    }

    scanPaused = true;
    if (btn) {
      btn.disabled = true;
      if (btn.classList.contains("ctwa-mer-banner__btn")) {
        btn.textContent = "Ouverture…";
      } else {
        btn.title = "Ouverture…";
      }
    }

    chrome.runtime.sendMessage(
      {
        type: "OPEN_MERIDIAN_SEARCH",
        payload: { query: trimmed },
      },
      (response) => {
        if (chrome.runtime.lastError) {
          if (btn) {
            btn.disabled = false;
            if (btn.classList.contains("ctwa-mer-banner__btn")) {
              btn.textContent = "Erreur — réessayer";
            } else {
              btn.title = "Erreur — réessayer";
            }
            setTimeout(() => {
              if (btn.classList.contains("ctwa-mer-banner__btn")) {
                btn.textContent = "Rechercher dans Meridian";
              } else {
                btn.title = "Rechercher dans Meridian";
              }
            }, 2000);
          }
          scanPaused = false;
          return;
        }

        if (btn) {
          if (btn.classList.contains("ctwa-mer-banner__btn")) {
            btn.textContent = response?.opened
              ? "Fiche lead ouverte ✓"
              : response?.ok
                ? "Recherche lancée ✓"
                : "Champ introuvable";
            setTimeout(() => {
              btn.disabled = false;
              btn.textContent = "Rechercher dans Meridian";
              scanPaused = false;
            }, 1500);
          } else {
            btn.title = response?.opened
              ? "Fiche lead Meridian ✓"
              : response?.ok
                ? "Recherche Meridian ✓"
                : "Meridian ouvert — champ introuvable";
            setTimeout(() => {
              btn.disabled = false;
              btn.title = "Rechercher dans Meridian";
              scanPaused = false;
            }, 1500);
          }
        } else {
          setTimeout(() => {
            scanPaused = false;
          }, 1500);
        }
      }
    );
  }

  function createMeridianTrigger(widget, panel) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "ctwa-trigger ctwa-trigger--meridian";
    btn.setAttribute("aria-label", "Rechercher dans Meridian");
    btn.setAttribute("aria-expanded", "false");
    btn.title = "Rechercher dans Meridian";
    btn.textContent = "M";

    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      e.preventDefault();
      const merBanner = widget.querySelector(`.${MER_BANNER_CLASS}`);
      if (merBanner) fillMeridianBanner(merBanner, getOpenPanel() || panel);
      toggleOverlay(widget, "mer");
    });

    return btn;
  }

  function openGhlSearch(query, btn) {
    const trimmed = (query || "").trim();
    if (!trimmed) {
      if (btn) {
        btn.textContent = "Aucun numéro détecté";
        setTimeout(() => {
          btn.textContent = "Rechercher dans GHL";
        }, 2000);
      }
      return;
    }

    scanPaused = true;
    if (btn) {
      btn.disabled = true;
      if (btn.classList.contains("ctwa-ghl-banner__btn")) {
        btn.textContent = "Ouverture…";
      } else {
        btn.title = "Ouverture…";
      }
    }

    chrome.runtime.sendMessage(
      {
        type: "OPEN_GHL_SEARCH",
        payload: { query: trimmed },
      },
      (response) => {
        if (chrome.runtime.lastError) {
          if (btn) {
            btn.disabled = false;
            if (btn.classList.contains("ctwa-ghl-banner__btn")) {
              btn.textContent = "Erreur — réessayer";
            } else {
              btn.title = "Erreur — réessayer";
            }
            setTimeout(() => {
              if (btn.classList.contains("ctwa-ghl-banner__btn")) {
                btn.textContent = "Rechercher dans GHL";
              } else {
                btn.title = "Rechercher dans GHL";
              }
            }, 2000);
          }
          scanPaused = false;
          return;
        }

        if (btn) {
          if (btn.classList.contains("ctwa-ghl-banner__btn")) {
            btn.textContent = response?.opened
              ? "Contact ouvert ✓"
              : response?.ok
                ? "Recherche lancée ✓"
                : "Champ introuvable";
            setTimeout(() => {
              btn.disabled = false;
              btn.textContent = "Rechercher dans GHL";
              scanPaused = false;
            }, 1500);
          } else {
            btn.title = response?.opened
              ? "Contact GHL ✓"
              : response?.ok
                ? "Recherche GHL ✓"
                : "GHL ouvert — champ introuvable";
            setTimeout(() => {
              btn.disabled = false;
              btn.title = "Rechercher dans GHL";
              scanPaused = false;
            }, 1500);
          }
        } else {
          setTimeout(() => {
            scanPaused = false;
          }, 1500);
        }
      }
    );
  }

  function createGhlTrigger(widget, panel) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "ctwa-trigger ctwa-trigger--ghl";
    btn.setAttribute("aria-label", "Rechercher dans GoHighLevel");
    btn.setAttribute("aria-expanded", "false");
    btn.title = "Rechercher dans GHL";
    btn.textContent = "GHL";

    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      e.preventDefault();
      const ghlBanner = widget.querySelector(`.${GHL_BANNER_CLASS}`);
      if (ghlBanner) fillGhlBanner(ghlBanner, getOpenPanel() || panel);
      toggleOverlay(widget, "ghl");
    });

    return btn;
  }

  function openTalentedCloser(url, btn) {
    scanPaused = true;
    if (btn) {
      btn.disabled = true;
      btn.title = "Ouverture…";
    }

    chrome.runtime.sendMessage(
      {
        type: "OPEN_TALENTED_CLOSER",
        payload: { url },
      },
      (response) => {
        if (chrome.runtime.lastError) {
          if (btn) {
            btn.disabled = false;
            btn.title = "Erreur — réessayer";
            setTimeout(() => {
              btn.title = "Ouvrir Talented Closer";
              scanPaused = false;
            }, 2000);
          } else {
            scanPaused = false;
          }
          return;
        }

        if (btn) {
          btn.title = response?.ok ? "Fiche TC ouverte ✓" : "Erreur — réessayer";
          setTimeout(() => {
            btn.disabled = false;
            btn.title = "Ouvrir Talented Closer";
            scanPaused = false;
          }, 1500);
        } else {
          setTimeout(() => {
            scanPaused = false;
          }, 1500);
        }
      }
    );
  }

  function createTalentedCloserTrigger(tcUrl) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "ctwa-trigger ctwa-trigger--tc";
    btn.setAttribute("aria-label", "Ouvrir la fiche Talented Closer");
    btn.title = "Ouvrir Talented Closer";

    const icon = document.createElement("img");
    icon.src = chrome.runtime.getURL("icons/talented-closer.png");
    icon.alt = "";
    icon.width = 20;
    icon.height = 20;
    btn.appendChild(icon);

    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      e.preventDefault();
      openTalentedCloser(tcUrl, btn);
    });
    return btn;
  }

  function openWhatsAppContact(contact, btn) {
    scanPaused = true;
    btn.disabled = true;
    btn.textContent = "Ouverture…";

    try {
      chrome.runtime.sendMessage({
        type: "OPEN_WHATSAPP_CONTACT",
        payload: contact,
      });
    } catch {
      btn.textContent = "Erreur — réessayer";
      btn.disabled = false;
      scanPaused = false;
      return;
    }

    btn.textContent = "WhatsApp ouvert ✓";
    closeAllOverlays(null, null);
    const widget = btn.closest(`.${WIDGET_CLASS}`);
    widget?.querySelector(`.${WA_BANNER_CLASS}`)?.classList.add(HIDDEN_CLASS);
    widget?.querySelector(".ctwa-trigger--wa")?.setAttribute("aria-expanded", "false");

    setTimeout(() => {
      btn.disabled = false;
      btn.textContent = "Créer ou ouvrir le contact";
      scanPaused = false;
    }, 1500);
  }

  function openOnoffContact(contact, btn) {
    scanPaused = true;
    btn.disabled = true;
    btn.textContent = "Ouverture…";

    try {
      chrome.runtime.sendMessage({
        type: "OPEN_ONOFF_CONTACT",
        payload: contact,
      });
    } catch {
      btn.textContent = "Erreur — réessayer";
      btn.disabled = false;
      scanPaused = false;
      return;
    }

    btn.textContent = "Onoff ouvert ✓";
    closeAllOverlays(null, null);
    const widget = btn.closest(`.${WIDGET_CLASS}`);
    widget?.querySelector(`.${ONOFF_BANNER_CLASS}`)?.classList.add(HIDDEN_CLASS);
    widget?.querySelector(".ctwa-trigger--onoff")?.setAttribute("aria-expanded", "false");

    setTimeout(() => {
      btn.disabled = false;
      btn.textContent = "Créer ou ouvrir sur Onoff";
      scanPaused = false;
    }, 1500);
  }

  function injectBanner(panel) {
    if (!panel) return;
    if (
      !enableWhatsApp &&
      !enableOnoff &&
      !enableTalentedCloser &&
      !enableMeridian &&
      !enableGhl
    ) {
      removeBanner(panel);
      return;
    }

    const phones = findPhonesInPanel(panel);
    const tcUrl = extractTalentedCloserUrlFromPanel(panel);
    const showWhatsApp = enableWhatsApp && phones.length > 0;
    const showOnoff = enableOnoff && phones.length > 0;
    const showTalentedCloser = enableTalentedCloser && !!tcUrl;
    const showMeridian = enableMeridian && phones.length > 0;
    const showGhl = enableGhl && phones.length > 0;

    if (!showWhatsApp && !showOnoff && !showTalentedCloser && !showMeridian && !showGhl) {
      removeBanner(panel);
      return;
    }

    if (panel.querySelector(`.${WIDGET_CLASS}`)) return;

    const widget = createWidget(
      phones,
      panel,
      cachedSuffixes.suffixes,
      cachedSuffixes.lastSuffix,
      { showWhatsApp, showOnoff, showTalentedCloser, tcUrl, showMeridian, showGhl }
    );

    const anchor =
      panel.querySelector('[role="heading"]')?.parentElement ||
      panel.firstElementChild;

    if (anchor) anchor.insertAdjacentElement("afterend", widget);
    else panel.prepend(widget);
  }

  function removeAllWidgets() {
    document.querySelectorAll(`.${WIDGET_CLASS}`).forEach((w) => w.remove());
  }

  function tick() {
    if (scanPaused) return;

    const panel = getOpenPanel();
    document.querySelectorAll(`.${WIDGET_CLASS}`).forEach((widget) => {
      if (!panel || !panel.contains(widget)) widget.remove();
    });

    if (!panel) return;

    injectBanner(panel);
  }

  function rescanAll() {
    removeAllWidgets();
    tick();
  }

  setInterval(tick, 1200);
  setTimeout(tick, 300);
  setTimeout(tick, 900);
})();
